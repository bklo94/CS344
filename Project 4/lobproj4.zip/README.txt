Brandon Lo 
CS344

Make sure that the grading script and compileall are executable 
then:
run "bash compileall"
run "./p4gradingscript PORT1 PORT2 > mytestresults 2>&1"
Brandon Lo
CS344
Project 3

Run make to create smallsh

smallsh should be executable now and can be tested with p3gradingscript

Run make clean to delete the junk, junk2 and smallsh files
